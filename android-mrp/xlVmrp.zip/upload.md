v1.0dev
- 完善socket
- 支持添加本地mrp
