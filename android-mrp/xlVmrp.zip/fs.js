var Module = typeof Module !== 'undefined' ? Module : {};
(function () {
    function runWithFS() {
        const path = window.location.pathname.substring(0, window.location.pathname.lastIndexOf('/')) + '/fs';

        var files = [
            "/mythroad/dsm_gm.mrp",
            "/mythroad/mrper.mrp",
            "/mythroad/capp_mrpoid.mrp",
            "/mythroad/ydqtwo.mrp",
            "/mythroad/plugins/netpay.mrp",
            "/mythroad/plugins/flaengine.mrp",
            "/mythroad/plugins/ose/brwcore.mrp",
            "/mythroad/system/gb12.uc2",
            "/mythroad/system/gb16.uc2",
            "/cfunction.ext",
            "/vmrp.mrp"
        ];
        //测试
        try{
            var fileList = js_getFileList("mythroad");
        fileList = fileList.split("\n")
        for(var i=0;i<fileList.length;i++){
            if(fileList[i].length == 0)continue;
            if(!files.includes("/mythroad/"+fileList[i]))
            files.push("/mythroad/"+fileList[i]) ;
        }
        }catch(e){
            console.log(e);
        };
        
        
        const dirs = [
            "/mythroad",
            "/mythroad/plugins",
            "/mythroad/plugins/ose",
            "/mythroad/system",
        ]


        for (const v of dirs) {
            FS.mkdir(v);
        }

        const dsm_gm = GetQueryString('f');
        for (const v of files) {
            const parent = v.substring(0, v.lastIndexOf('/'));
            const name = v.substring(v.lastIndexOf('/') + 1);
            if (dsm_gm && name === 'dsm_gm.mrp') {
                FS.createPreloadedFile(parent, name, path + dsm_gm, true, true);
            } else {
                FS.createPreloadedFile(parent, name, path + v, true, true);
            }
        }

        
        // console.log(fileList);
        // for (const item of fileList) {
        //     const parent = item.substring(0, item.lastIndexOf('/'));
        //     const name = item.substring(item.lastIndexOf('/') + 1);
        //     if(item.length == 0)continue;
            
        //     if (name === 'dsm_gm.mrp') {
        //         FS.createPreloadedFile(parent, name, path + "/mythroad/" + item, true, true);
        //     } else {
        //         FS.createPreloadedFile(parent, name, path + "/mythroad/" + encodeURI(item), true, true);
        //     }
        // }
    }


    if (!Module['preRun']) Module['preRun'] = [];
    Module["preRun"].push(runWithFS);
})();
